const SoldHistory = require("../schemas/sold");

async function updateAndGetStatistics(userId) {
  console.log("Processing buyer interaction...");

  let soldout = await SoldHistory.findOne({});
  
  if (!soldout) {
    soldout = await SoldHistory.create({
      sold: 0,
      buyerCount: 0,
      uniqueBuyers: [],
    });
  }

  const isNewBuyer = !soldout.uniqueBuyers.includes(userId);

  if (isNewBuyer) {
    await SoldHistory.updateOne(
      {},
      {
        $push: { uniqueBuyers: userId },
        $inc: { buyerCount: 1, sold: 1 },
      }
    );
  } else {
    await SoldHistory.updateOne({}, { $inc: { sold: 1 } });
  }

  const updatedStats = await SoldHistory.findOne({});
  return {
    totalOrders: updatedStats.sold,
    totalBuyers: updatedStats.buyerCount,
  };
}

async function getTotalOrders() {
  const soldout = await SoldHistory.findOne({});
  return soldout ? soldout.sold : 0;
}

async function getTotalBuyers() {
  const soldout = await SoldHistory.findOne({});
  return soldout ? soldout.buyerCount : 0;
}

module.exports = {
  updateAndGetStatistics,
  getTotalOrders,
  getTotalBuyers,
};