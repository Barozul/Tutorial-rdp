const { EmbedBuilder } = require("discord.js");

const howToBuyInfo = async (interaction) => {
  await interaction.reply({
    embeds: [
      new EmbedBuilder()
        .setColor("#313135")
        .setDescription(
          `**1.** Click the **Deposit** button.\n**2.** Set your GrowID by clicking the **Set** button.\n**3.** Once done, proceed to the deposit world and deposit your Wls (Make sure there's a donation bot available).\n**4.** Check your balance by clicking the **Check Balance** button. After that, click the **Buy** button to purchase what you need.`
        ),
    ],
    ephemeral: true,
  });
};
module.exports = { howToBuyInfo };
