const { ApplicationCommandType } = require("discord.js");
const Stock = require("../../schemas/stock");

module.exports = {
  name: "editdescription",
  description: "Edit the description of a specific stock code.",
  type: ApplicationCommandType.ChatInput,
  options: [
    {
      name: "code",
      description: "The stock code to edit.",
      type: 3,
      required: true,
    },
    {
      name: "description",
      description: "The new description for the stock.",
      type: 3,
      required: true,
    },
  ],
  run: async (client, interaction) => {
    try {
      const code = interaction.options.getString("code");
      const newDescription = interaction.options.getString("description");

      const stock = await Stock.findOneAndUpdate(
        { code },
        { description: newDescription },
        { new: true }
      );

      if (!stock) {
        return interaction.reply({
          content: `Stock with code \`${code}\` not found.`,
          ephemeral: true,
        });
      }

      await interaction.reply({
        content: `Description for code \`${code}\` has been updated.`,
        ephemeral: true,
      });
    } catch (error) {
      console.error("Error updating stock description:", error);
      await interaction.reply({
        content: "An error occurred while updating the stock description.",
        ephemeral: true,
      });
    }
  },
};
