const { ApplicationCommandType, EmbedBuilder } = require("discord.js");
const Users = require("../../schemas/users");

module.exports = {
  name: "checkbalance",
  description: "Cek saldo dari pengguna tertentu.",
  type: ApplicationCommandType.ChatInput,
  options: [
    {
      name: "user",
      description: "Nama pengguna",
      type: 6,
      required: true,
    },
  ],
  run: async (client, interaction) => {
    try {
      const user = interaction.options.getUser("user");

      const userBalance = await Users.findOne({ discordid: user.id });

      if (!userBalance) {
        return interaction.reply({
          content: `Balancr **${user.username}** 0.`,
          ephemeral: true,
        });
      }
const balance = userBalance.jumlah;
const bglCount = Math.floor(balance / 10000);
const remainingAfterBgl = balance % 10000;
const dlCount = Math.floor(remainingAfterBgl / 100);
const wlCount = remainingAfterBgl % 100; 
 
      const balanceEmbed = new EmbedBuilder()
        .setColor("#313135")
        .setDescription(
          `**GrowID**: ${userBalance.namaplayer || "Tidak tersedia"}\n`+
          `**Balance**: ${bglCount} ${process.env.BGL} ${dlCount} ${process.env.DL} ${wlCount} ${process.env.WL}\n`
        )
        .setFooter({ text: `Diminta oleh ${interaction.user.tag}` })
        .setTimestamp();

      await interaction.reply({
        embeds: [balanceEmbed],
        ephemeral: true,
      });
    } catch (error) {
      console.error("Error fetching user balance:", error);
      await interaction.reply({
        content: "Terjadi kesalahan saat mengambil data pengguna. Silakan coba lagi nanti.",
        ephemeral: true,
      });
    }
  },
};
