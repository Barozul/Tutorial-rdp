const schema = require("../../schemas/users");
const { EmbedBuilder, ApplicationCommandType } = require('discord.js');

module.exports = {
  name: 'remove',
  description: "Remove balance of the members.",
  cooldown: 2,
  ownerOnly: true,
  type: ApplicationCommandType.ChatInput,
  default_member_permissions: 'ManageGuild', 
  options: [
    {
      name: 'balance',
      description: 'remove balance from a user.',
      type: 1,
      options: [
        {
          name: 'user',
          description: 'The user you want to remove balance from.',
          type: 6,
          required: true
        },
        {
          name: 'amount',
          description: 'The amount you want to remove.',
          type: 4,
          required: true
        }
      ]
    }
  ],
  run: async (client, interaction) => {
    let user = interaction.options.getUser("user");
    let amount = interaction.options.getInteger("amount");

    const datas = await schema.findOne({
      discordid: user.id, 
    });

    if (!datas) {
      return interaction.reply({
        content: `User tersebut belum registrasi.`,
        ephemeral: true,
      });
    }

    if (typeof datas.jumlah !== 'number' || datas.jumlah < amount) {
      return interaction.reply({
        content: `Balance tidak mencukupi untuk pengurangan ini.`,
        ephemeral: true,
      });
    }

    datas.jumlah -= amount; 
    await datas.save();

    const removeBalanceEmbed = new EmbedBuilder()
      .setColor("Red")
      .setDescription(
        `You removed **${amount} ${process.env.WL}** from **${user.username}#${user.discriminator}**.`
      );

    await interaction.reply({
      embeds: [removeBalanceEmbed],
      ephemeral: true,
    });
  },
};