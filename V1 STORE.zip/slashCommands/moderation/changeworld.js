const { ApplicationCommandType, EmbedBuilder } = require("discord.js");
const Depo = require("../../schemas/depo");

module.exports = {
  name: "change",
  description: "change World.",
  cooldown: 2,
  ownerOnly: true,
  type: ApplicationCommandType.ChatInput,
  default_member_permissions: "Administrator", // permission required
  options: [
    {
      name: "world",
      description: "change World.",
      type: 1,
      options: [
        {
          name: "world",
          description: "Input World Depo",
          type: 3,
          required: true,
        },
        {
          name: "owner",
          description: "Input Owner Depo",
          type: 3,
          required: true,
        },
        {
          name: "bot",
          description: "Input Bot Depo",
          type: 3,
          required: true,
        },
      ],
    },
  ],
  run: async (client, interaction) => {
    const world = interaction.options.getString("world").toUpperCase();
    const owner = interaction.options.getString("owner").toUpperCase();
    const bot = interaction.options.getString("bot");

    const deposit = await Depo.findOne({});
    if (!deposit) {
      await Depo.create({
        world: world,
        owner: owner,
        bot: bot,
      });

      await interaction.reply({
        content: `Success Create\nWorld Depo: ${world}\nOwner Depo: ${owner}\nBot In World: ${bot}`,
        ephemeral: true,
      });
    } else {
      deposit.world = world;
      deposit.owner = owner;
      deposit.bot = bot;
      deposit.save();

      await interaction.reply({
        content: `Success Update\nWorld Depo: ${world}\nOwner Depo: ${owner}\nBot In World: ${bot}`,
        ephemeral: true,
      });
    }
  },
};
