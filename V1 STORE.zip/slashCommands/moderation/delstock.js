const { deleteAllStock } = require("../../handlers/handlerStock");
const { EmbedBuilder, ApplicationCommandType } = require('discord.js');

module.exports = {
  name: 'removestock',
  description: "Remove all stock for a product in the database.",
  cooldown: 2,
  ownerOnly: true,
  type: ApplicationCommandType.ChatInput,
  default_member_permissions: 'Administrator',
  options: [
        {
          name: 'kode',
          description: 'Product code to remove all stock.',
          type: 3,
          required: true,
        }
  ],
  run: async (client, interaction) => {
    const code = interaction.options.getString("kode");

    const embed = new EmbedBuilder()
      .setColor("LuminousVividPink")
      .setDescription(`All stock for product code ${code} has been removed.`)
      .setFooter({
        text: `Interaction by ${interaction.user.username}`
      })
      .setTimestamp();

    const success = await deleteAllStock(code);
    if (success) {
      await interaction.reply({ embeds: [embed], ephemeral: true });
      return;
    } else {
      await interaction.reply({ content: `No stock found for product code ${code}.`, ephemeral: true });
      return;
    }
  },
};
