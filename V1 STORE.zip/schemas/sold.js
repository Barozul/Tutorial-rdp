const mongoose = require('mongoose');

const stockSchema = new mongoose.Schema({
    sold:{
        type: Number,
        required: true,
   },
    buyerCount: {
    type: Number,
    required: true,
    default: 0,
  },
    uniqueBuyers: {
    type: [String],
    default: [],
  },
});

const Sold = mongoose.model('Sold', stockSchema);

module.exports = Sold;
