const mongoose = require('mongoose');

const dataSchema = mongoose.Schema({
    discordid:{
        type: String,
        required: true,
    },
    namaplayer:{
        type: String,
        required: true,
    },
    total_depo:{
        type: Number,
        required: true,
    },
    jumlah:{
        type: Number,
        required: true,
    },
},{
    timestamps: true
})

module.exports = mongoose.model('Users',dataSchema)