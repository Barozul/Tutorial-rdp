const mongoose = require("mongoose");

const stockSchema = new mongoose.Schema({
   description: {
    type: String,
    default: "",
   },
    code: {
    type: String,
    required: true,
    unique: true,
  },
  desc: {
    type: String,
    required: true,
  },
  harga: {
    type: Number,
    required: true,
  },
  data: {
    type: Array,
    default: [],
  },
  role: {
    type: String,
    required: true,
  },
});

module.exports = mongoose.model("Stock", stockSchema);
