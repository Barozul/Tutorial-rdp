TYPE SCRIPT: discord.js v14

HOW TO SETUP
1. buka .env dan setting { token, channel id, emoji }
2. selanjutnya jika sudah buka folder json => config.json dan setting { mongodb token, owner id, dll }
3. setelah selesai melakukan setting silahkan jalankan scriptnya.

HOW TO RUN
1. masuk ke direktori file dari script ini
2. buka terminal / CLI
3. ketik perintah: node .
4. selesai